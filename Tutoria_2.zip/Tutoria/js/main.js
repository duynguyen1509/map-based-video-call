//noinspection JSCheckFunctionSignatures,JSCheckFunctionSignatures,JSCheckFunctionSignatures
var game = new Phaser.Game(
  20 * 16,
  20 * 16,
  Phaser.AUTO, // renderer
  document.getElementById("game") //parent-element : where it will be loaded
);
game.state.add("Game", Game);
game.state.start("Game");
