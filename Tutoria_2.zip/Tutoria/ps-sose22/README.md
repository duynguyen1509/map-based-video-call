# PS-SoSe22

Entwicklung einer umgebungsbewussten, kartenbasierten, mobilen Videocall-
Anwendung zur Unterstützung des digitalen Lehrbetriebs


## Projekt klonen
```
git clone https://gitlab.gwdg.de/ps-mob-sose22/gruppe-3-videocall-anwendung-zur-unterstuetzung-des-digitalen-lehrbetriebs/ps-sose22.git
```

## Dependencies installieren
```
npm install peerjs (auf Mac: sudo npm install peerjs)
npm install
```

## Testen
```
node server.js
peerjs --port 3002
```
Im Browser dann `localhost:8081` eingeben








